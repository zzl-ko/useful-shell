#!/bin/bash

echo "This is a test script that is called when the package is executed"

echo "Father's EXTRACT_DIR is [$EXTRACT_DIR]"

echo "Now you can custom your actions via the script makeSelfExtracting.sh" 
